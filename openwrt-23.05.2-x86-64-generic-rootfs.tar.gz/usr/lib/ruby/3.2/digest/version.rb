# frozen_string_literal: true

module Digest
  VERSION = "3.1.1"
end
